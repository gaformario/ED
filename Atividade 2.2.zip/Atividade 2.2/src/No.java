public class No {
    No prox;
    No ant;
    Paciente paciente;


    public No(Paciente paciente) {
        this.paciente = paciente;
    }
}
